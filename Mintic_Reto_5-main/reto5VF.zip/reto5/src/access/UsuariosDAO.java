/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package access;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import models.UsuariosModel;
import java.util.*;
import utils.ConnectionDB;

/**
 *
 * @author user
 */
public class UsuariosDAO {

    private Connection conn;

    public ArrayList<UsuariosModel> obtenerUsuarios() {
        ArrayList<UsuariosModel> usuarios = new ArrayList<>();

        try {
            if (conn == null) {
                conn = ConnectionDB.getConnection();
            }
            String sql = "SELECT usuario.correo_electronico as Correo, usuario.nombres as Nombre, usuario.apellidos as Apellidos, usuario.edad as Edad, usuario.contrasena as \"Contraseña\", usuario.id_rol as \"ID Rol\" FROM usuarios usuario;";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                UsuariosModel rol = new UsuariosModel(result.getString(1), result.getString(2), result.getString(3), result.getInt(4), result.getString(5), result.getInt(6));
                usuarios.add(rol);
            }

        } catch (SQLException ex) {
            System.err.println(ex);
        }

        return usuarios;
    }


public UsuariosModel obtenerUsuario(String correoElectronico) {
UsuariosModel usuario= null;
try {
            if (conn == null) {
                conn = ConnectionDB.getConnection();
            }
            String sql = "SELECT usuario.correo_electronico as Correo, usuario.nombres as Nombre, usuario.apellidos as Apellidos, usuario.edad as Edad, usuario.contrasena as \"Contraseña\", usuario.id_rol as \"ID Rol\" FROM usuarios usuario WHERE usuario.correo_electronico=?;";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1,correoElectronico );
            ResultSet result = statement.executeQuery();
            while (result.next()) {
            usuario = new UsuariosModel(result.getString(1), result.getString(2), result.getString(3), result.getInt(4), result.getString(5), result.getInt(6));

            }
        } catch (SQLException ex) {
            System.err.println(ex);
        }
return usuario;
    }

    public void agregarUsuario(UsuariosModel usuario) {
        try {
            if (conn == null) {
                conn = ConnectionDB.getConnection();
            }
            String sql = "INSERT INTO usuarios (correo_electronico, nombres , apellidos, edad, contrasena, id_rol) VALUES(?,?,?,?,?,?)";
            PreparedStatement statement = conn.prepareStatement(sql);

            //Aquí se pueden empezar a crear las excepciones 
            statement.setString(1, usuario.getCorreoElectronico());
            statement.setString(2, usuario.getNombres());
            statement.setString(3, usuario.getApellidos());
            statement.setInt(4, usuario.getEdad());
            statement.setString(5, usuario.getContraseña());
            statement.setInt(6, usuario.getIdRol());

            int rowsInsert = statement.executeUpdate();
            if (rowsInsert > 0) {
                System.out.println(" El usuario ha sido agregado");
            } else {
                System.out.println(" No se logró agregar el usuario");
            }

        } catch (SQLException ex) {
            System.err.println(ex);
        }
    }

    public void actualizarUsuario(UsuariosModel usuario) {
        try {
            if (conn == null) {
                conn = ConnectionDB.getConnection();
            }
            
            String sql = "UPDATE usuarios SET nombres=?,apellidos=?,edad=?,contrasena=?,id_rol=? WHERE correo_electronico=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            if (!usuario.getCorreoElectronico().isEmpty()){
            statement.setString(6, usuario.getCorreoElectronico());}
            else {statement.setString(6, "Por favor digite un Correo Electrónico");}
            if (!usuario.getNombres().isEmpty())
            statement.setString(1, usuario.getNombres());
            else{statement.setString(2,"Por favor digite un nombre");}
            if (usuario.getApellidos().isEmpty())
            statement.setString(2, usuario.getApellidos());
            else{statement.setString(2,"Por favor digite un apellido");}
            if (Integer.toString(usuario.getEdad()).matches("[0-9]+") &&  !Integer.toString(usuario.getEdad()).isEmpty())
            statement.setInt(3, usuario.getEdad());
            else{statement.setString(3, "Por favor digite una edad válida");}
            if (!usuario.getContraseña().isEmpty())
            statement.setString(4, usuario.getContraseña());
            else{statement.setString(4, "Por favor digite una contraseña");}
            if (Integer.toString(usuario.getIdRol()).matches("[0-9]+") &&  !Integer.toString(usuario.getIdRol()).isEmpty())
            statement.setInt(5, usuario.getIdRol());
            else {statement.setString(5,"Por favor digite un ID válido");}
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0)
                System.out.println("El registro fue actualizado exitosamente !");
        } catch (SQLException ex) {
            System.err.println(ex);
        }
        
    }

    public void eliminarUsuario(String correoElectronico) {
        try {
            if (conn == null) {
                conn = ConnectionDB.getConnection();
            }
            String sql = "DELETE from usuarios WHERE correo_electronico=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, correoElectronico);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("El registro fue eliminado exitosamente !");
            }
            else {System.out.println("Por favor digite un Correo Electrónico");}
        } catch (SQLException ex) {
            System.err.println(ex);
            
        }
    }   
    }



