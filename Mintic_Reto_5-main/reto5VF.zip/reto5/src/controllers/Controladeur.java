/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import access.UsuariosDAO;
import java.util.*;
import models.UsuariosModel;

public class Controladeur {

    private UsuariosDAO usuariosDAO;

    public Controladeur() {
        usuariosDAO = new UsuariosDAO();
    }
    
    public ArrayList<UsuariosModel> obtenerUsuarios() {
        return usuariosDAO.obtenerUsuarios();
    }
    
    public UsuariosModel obtenerUsuario(String correoElectronico) {
        return usuariosDAO.obtenerUsuario(correoElectronico);
    }
    
    public void agregarUsuario(String correoElectronico, String nombres, String apellidos, int edad, String contraseña, int idRol) {
        UsuariosModel user = new UsuariosModel(correoElectronico, nombres, apellidos, edad, contraseña, idRol);
        usuariosDAO.agregarUsuario(user);
    }
    
    public void actualizaUsuario(String correoElectronico, String nombres, String apellidos, int edad, String contraseña, int idRol) {
        UsuariosModel user = new UsuariosModel(correoElectronico, nombres, apellidos, edad, contraseña, idRol);
        usuariosDAO.actualizarUsuario(user);
    }
    
    public void eliminarUsuario(String correoElectronico) {
        usuariosDAO.eliminarUsuario(correoElectronico);
    }
    
}
