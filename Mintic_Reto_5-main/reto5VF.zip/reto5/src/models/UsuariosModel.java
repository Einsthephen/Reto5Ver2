/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author user
 */
public class UsuariosModel {
    private String correoElectronico;
    private String nombres;
    private String apellidos;
    private int edad;
    private String contraseña; 
    private int idRol;
    /** 
     * Constructor para el manejo interno de la tabla
     * @param correoElectronico
     * @param nombres
     * @param apellidos
     * @param edad
     * @param contraseña
     * @param idRol 
     */
    public UsuariosModel(String correoElectronico,String nombres,String apellidos,int edad,String contraseña,int idRol){
    this.correoElectronico   = correoElectronico;
    this.nombres             = nombres;
    this.apellidos           = apellidos;
    this.edad                = edad;
    this.contraseña          = contraseña;
    this.idRol               = idRol;
    }

    /**
     * @return the correoElectronico
     */
    public String getCorreoElectronico() {
        return correoElectronico;
    }

    /**
     * @return the nombres
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * @param nombres the nombres to set
     */
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    /**
     * @return the apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * @param apellidos the apellidos to set
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * @return the edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the edad to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * @return the contraseña
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * @param contraseña the contraseña to set
     */
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    /**
     * @return the idRol
     */
    public int getIdRol() {
        return idRol;
    }

    /**
     * @param idRol the idRol to set
     */
    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }
    
    @Override
    public String toString() {
        return "Correo: " + correoElectronico  + " | Nombre: " + nombres + " | Apellido: " + apellidos + " | edad: " + edad + " | contraseña: " + contraseña + " | IdRol: " + idRol ;
    }
}
